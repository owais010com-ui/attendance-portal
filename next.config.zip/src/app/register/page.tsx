"use client";

import { useState } from "react";
import axios from "axios";

export default function RegisterPage() {
    const [form, setForm] = useState({
        name: "",
        email: "",
        password: "",
        employeeId: "",
        role: "admin",
    });

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        try {
            const { data } = await axios.post("/api/auth/register", form);
            alert(data.message);
        } catch (err: any) {
            alert(err.response?.data?.message || "Error");
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center">
            <form onSubmit={handleSubmit} className="space-y-4 w-96">

                <input
                    placeholder="Name"
                    className="border p-2 w-full"
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                />

                <input
                    placeholder="Email"
                    className="border p-2 w-full"
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                />

                <input
                    type="password"
                    placeholder="Password"
                    className="border p-2 w-full"
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                />

                <input
                    placeholder="Employee ID"
                    className="border p-2 w-full"
                    onChange={(e) => setForm({ ...form, employeeId: e.target.value })}
                />

                <button className="bg-blue-600 text-white p-2 w-full rounded">
                    Create Admin
                </button>

            </form>
        </div>
    );
}
